import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow import keras
from keras.models import Model
from keras.layers import Input, LSTM, Dense, Conv2D, MaxPooling2D, Flatten, Concatenate, Reshape
from sklearn.model_selection import train_test_split

# 生成模拟数据 (30场洪水事件)
def generate_synthetic_data(num_events, T, N, M):
    rainfall = np.random.rand(num_events, T, 1)  # 降雨数据 (30×T×1)
    evaporation = np.random.rand(num_events, T, 1)  # 蒸发数据 (30×T×1)
    dem = np.random.rand(N, M)  # 地形数据 (N×M) (固定不随时间变化)
    flood_depth = np.random.rand(num_events, T, N, M)  # 淹没水深数据 (30×T×N×M)
    return rainfall, evaporation, dem, flood_depth

# 数据预处理
def preprocess_data(rainfall, evaporation, dem, flood_depth):
    # 合并降雨和蒸发数据为输入特征 (30×T×2)
    meteo_data = np.concatenate([rainfall, evaporation], axis=-1)
    # 将地形数据扩展为 (30×N×M×1)
    dem_data = np.tile(dem[np.newaxis, :, :, np.newaxis], (rainfall.shape[0], 1, 1, 1))
    return meteo_data, dem_data, flood_depth

from keras.layers import Attention

# 构建模型，加入Attention机制
def build_model_with_attention(T, N, M):
    # 气象数据 (T×2)
    meteo_input = Input(shape=(T, 2), name="meteo_input")
    shared_lstm = LSTM(8, return_sequences=True, name="shared_lstm")(meteo_input)
    
    # Attention机制
    attention = Attention(name="attention_layer")([shared_lstm, shared_lstm])
    attention_output = Dense(8, activation="relu", name="attention_dense")(attention)

    # 地形数据 (N×M×1)
    dem_input = Input(shape=(N, M, 1), name="dem_input")
    cnn_output = Conv2D(8, kernel_size=(3, 3), activation='relu', name="cnn_conv1")(dem_input)
    cnn_output = MaxPooling2D(pool_size=(2, 2), name="cnn_pool1")(cnn_output)
    cnn_output = Flatten(name="cnn_flatten")(cnn_output)

    # 融合气象和地形特征
    merged = Concatenate(name="feature_concatenate")([Flatten()(attention_output), cnn_output])

    # 全连接层
    dense_output = Dense(8, activation='relu', name="fc_dense1")(merged)
    dense_output = Dense(T * N * M, activation='linear', name="fc_dense2")(dense_output)

    # 输出层
    final_output = Reshape((T, N, M), name="output_reshape")(dense_output)

    # 构建模型
    model = Model(inputs=[meteo_input, dem_input], outputs=final_output)
    model.compile(optimizer='adam', loss='mse', metrics=['mae'])
    return model
# 主程序


if __name__ == "__main__":
    # 参数设置
    num_events = 26  # 洪水事件数
    T = 100 # 时间步长
    N, M = 599, 967  # 地形数据尺寸
    epochs = 2
    batch_size = 4

    # 生成数据
    rainfall, evaporation, dem, flood_depth = generate_synthetic_data(num_events, T, N, M)
    meteo_data, dem_data, target_data = preprocess_data(rainfall, evaporation, dem, flood_depth)

    # 划分训练集和测试集
    X_train_meteo, X_test_meteo, X_train_dem, X_test_dem, y_train, y_test = train_test_split(
        meteo_data, dem_data, target_data, test_size=0.2, random_state=42
    )

    # 构建模型
  
    model = build_model_with_attention(T, N, M)
    from keras.utils import plot_model

# 构建带有Attention机制的模型


# 绘制模型结构
    plot_model(model, to_file='model_with_attention.png', show_shapes=True, show_layer_names=True)

    # 可视化并保存为图片
    plt.figure(figsize=(10, 10))
    plt.imshow(plt.imread('model_with_attention.png'))
    plt.axis('off')
    plt.show()
    model.summary()

    # 训练模型
    history = model.fit(
        [X_train_meteo, X_train_dem],
        y_train,  # 目标数据不需要再展平，保持原始形状 (batch_size, T, N, M)
        epochs=epochs,
        batch_size=batch_size,
        validation_data=(
            [X_test_meteo, X_test_dem],
            y_test  # 同样的，目标数据不展平
        )
    )



    # 保存模型
    model.save("flood_prediction_model.h5")

    # 可视化训练过程
    plt.figure(figsize=(10, 5))
    plt.plot(history.history['loss'], label='Training Loss')
    plt.plot(history.history['val_loss'], label='Validation Loss')
    plt.plot(history.history['mae'], label='Training MAE')
    plt.plot(history.history['val_mae'], label='Validation MAE')
    plt.title('Training and Validation Loss/MAE')
    plt.xlabel('Epoch')
    plt.ylabel('Loss/MAE')
    plt.legend()
    plt.savefig("training_loss_mae.png")
    plt.show()

    # 测试模型滚动预测
    test_index = 0  # 选择一场洪水事件
    test_meteo = X_test_meteo[test_index:test_index+1]
    test_dem = X_test_dem[test_index:test_index+1]
    test_target = y_test[test_index]

    predictions = []
    for t in range(T):
        prediction = model.predict([test_meteo[:, :t+1, :], test_dem])
        predictions.append(prediction[0])

    predictions = np.array(predictions).reshape(T, N, M)

    # 可视化某时刻的预测结果
    plt.figure(figsize=(10, 5))
    plt.subplot(1, 2, 1)
    plt.imshow(test_target[0], cmap='viridis', origin='lower')
    plt.title('True Flood Depth (t=0)')
    plt.colorbar()

    plt.subplot(1, 2, 2)
    plt.imshow(predictions[0], cmap='viridis', origin='lower')
    plt.title('Predicted Flood Depth (t=0)')
    plt.colorbar()

    plt.savefig("predicted_vs_true_flood_depth.png")
    plt.show()
