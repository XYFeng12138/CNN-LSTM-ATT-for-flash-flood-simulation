import os
import numpy as np

# 参数设置
NUM_SAMPLES = 2  # 样本数量
TIME_STEPS = 100    # 时间步长 (T)
#DEM_SIZE = (32, 32)  # DEM 数据的空间大小 (X, Y)

# 随机生成降雨数据 (降雨强度 0-100 mm)
#rainfall_data = np.random.uniform(0, 100, size=(NUM_SAMPLES, TIME_STEPS, 1)).astype(np.float32)

ppet_folder_path = "./petptest/"  # 替换为你的文件夹路径
asc_file_path = "./pjdem.asc"  # 替换为你的ASC文件路径
rainfall_output_file = "rainfall_data_test.npy"  # 输出的降雨数据文件名
evaporation_output_file = "evaporation_data_test.npy"  # 输出的蒸发数据文件名
dem_output_file = "dem_data_test.npy"  # 输出的npy文件名

flood_folder_path = "./floodtest/"  # 替换为你的文件夹路径
flood_output_file = "target_data_test.npy"  # 输出的npy文件名

# 存储降雨和蒸发数据
rainfall_data = []
evaporation_data = []

# 遍历文件夹中的所有txt文件

for file_name in sorted(os.listdir(ppet_folder_path), key=lambda x: int(x.split('_')[0])):
    if file_name.endswith(".txt"):  # 只处理txt文件
        file_path = os.path.join(ppet_folder_path, file_name)
        print(file_path)
        data = np.loadtxt(file_path)  # 假设文件以空格或制表符分隔
        rainfall_data.append(data[:TIME_STEPS, 0])  # 第一列是降雨数据  前100行
        evaporation_data.append(data[:TIME_STEPS, 1])  # 第二列是蒸发数据
        # 添加当前文件的数据，调整形状为 (T, 1)


# 合并所有文件的数据
rainfall_data = np.expand_dims(np.array(rainfall_data), axis=-1)  # 形状为 (12, T, 1)
evaporation_data = np.expand_dims(np.array(evaporation_data), axis=-1)  # 形状为 (12, T, 1)

# 保存为 .npy 文件




# 读取ASC文件内容并解析为numpy数组
with open(asc_file_path, 'r') as file:
    for _ in range(6):  # 跳过前6行
        next(file)
    dem_data = np.loadtxt(file)  # 读取栅格数据部分

# 复制12次并调整形状为 (NUM_SAMPLES, N, M, 1)
raster_data = np.tile(dem_data, (NUM_SAMPLES, 1, 1))  # 复制12次，形状变为 (12, N, M)
raster_data = np.expand_dims(raster_data, axis=-1)  # 添加最后一个维度，变为 (12, N, M, 1)

# 保存为 .npy 文件


# 存储所有子文件夹的数据
all_data = []

# 遍历父文件夹中的所有子文件夹，按数字顺序排序
for sub_folder_name in sorted(os.listdir(flood_folder_path),  key=lambda x: int(x[2:])):
    sub_folder_path = os.path.join(flood_folder_path, sub_folder_name)
    if os.path.isdir(sub_folder_path):  # 确保是文件夹
        sub_folder_data = []

        # 遍历子文件夹中的所有文件，首先过滤出 .asc 文件
        asc_files = [f for f in os.listdir(sub_folder_path) if f.endswith('.wd')]
        
        # 按文件名中的数字部分排序，确保按照顺序读取
        asc_files = sorted(asc_files, key=lambda x: int(x.split('.')[0].split('-')[1]))  # 假设文件名格式为 gts1975-0001.asc
        asc_files = asc_files[:TIME_STEPS]   # 时间尺度
        # 读取排序后的 .asc 文件
        for file_name in asc_files:
            file_path = os.path.join(sub_folder_path, file_name)
            print(file_path)
            # 读取ASC文件内容并跳过头部信息（假设头部为6行）
            with open(file_path, 'r') as file:
                for _ in range(6):  # 跳过前6行
                    next(file)
                data = np.loadtxt(file)  # 读取栅格数据部分
            sub_folder_data.append(data)

        # 将子文件夹的数据堆叠为 (T, N, M)
        sub_folder_data = np.array(sub_folder_data)  # 形状为 (T, N, M)
        all_data.append(sub_folder_data)

# 将所有子文件夹的数据堆叠为 (n, T, N, M)
all_data = np.array(all_data)  # 形状为 (n, T, N, M)

# 保存为 .npy 文件

np.save(rainfall_output_file, rainfall_data)
np.save(evaporation_output_file, evaporation_data)
np.save(dem_output_file, raster_data)
np.save(flood_output_file, all_data)

print(f"组合数据已保存到 {flood_output_file}，数据形状为 {all_data.shape}")
print(f"栅格数据已保存到 {dem_output_file}，数据形状为 {raster_data.shape}")
print(f"降雨数据已保存到 {rainfall_output_file}，数据形状为 {rainfall_data.shape}")
print(f"蒸发数据已保存到 {evaporation_output_file}，数据形状为 {evaporation_data.shape}")


# 随机生成 DEM 数据 (高程 0-500 m)
#dem_data = np.random.uniform(0, 500, size=(NUM_SAMPLES, DEM_SIZE[0], DEM_SIZE[1], 1)).astype(np.float32)
# 随机生成目标淹没水深数据 (水深 0-10 m)
#target_data = np.random.uniform(0, 10, size=(NUM_SAMPLES, TIME_STEPS, DEM_SIZE[0], DEM_SIZE[1])).astype(np.float32)
print("Input data has been generated and saved.")

