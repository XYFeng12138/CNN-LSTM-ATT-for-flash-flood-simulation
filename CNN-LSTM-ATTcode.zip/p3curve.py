from scipy.special import gdtrix, ndtri     #引入伽马累积分布函数的反函数与正态分布的分位数，
import matplotlib.pylab as plt
from matplotlib import font_manager
import numpy as np
import pandas as pd
from matplotlib import rcParams
from matplotlib.ticker import MaxNLocator

plt.rcParams['font.family'] = 'Times New Roman'

def xtrans(plist):  # plist传入的是一个p值列表数据，plist必须是概率值，返回的xplist也是一个列表数据
    xzero = ndtri(0.0001)
    xplist = []
    for i in range(len(plist)):
        xplisti = ndtri(plist[i] / 100)
        xplisti -= xzero
        xplist.append(xplisti)
    return xplist
def jlxs(plist, cs):
    aa = 4 / cs ** 2    #即公式中的阿尔法值
    tp = []  # 为求离均系数fp，tp是过渡
    fp = []
    for i in range(len(plist)):  # 离均系数fp
        tpi = round(gdtrix(1, aa, 1 - plist[i] / 100), 3)  # 采用了标准伽马分布，a=1
        fpi = round(cs * tpi / 2 - 2 / cs, 3)
        tp.append(tpi)
        fp.append(fpi)
    return fp  # 返回的fp也是一个列表数据


df=pd.read_excel('annual_peak_flow.xlsx')
Q=list(df['peak_flow'])

# 坐标轴的绘制
# pstandard = [0.01, 0.02, 0.05, 0.1, 0.2, 0.5, 1.0, 2.0, 3.0, 5.0, 10.0, 20.0, 25.0,30.0, 40.0, 50.0, 60.0, 70.0, 75.0, 80.0, 90.0, 95.0, 97.0, 99.0, 99.5, 99.9]
pstandard = [0.01,0.05,  0.5, 1.0, 2.0, 3.0, 5.0, 10.0, 20.0,30.0, 40.0, 50.0, 60.0, 70.0,80.0, 90.0, 95.0, 97.0, 99.0, 99.5, 99.9]

x_axis = ['0.01', '0.05', '0.5', '1', '2','3','5','10','20','30','40','50','60','70','80','90','95','97','99','99.5','99.9']  # 自定义横坐标的标签
#x_axis = [str(i) + '' for i in pstandard]
x = xtrans(pstandard)
factor = 1.5 
y_axis = np.linspace(0, 3000, 11, dtype=np.float32)
y_ticks = y_axis.astype(int)  # 转换为整数

# 应用这些刻度

#print(x_axis, y_axis, sep='\n')
# print(x)
# 建立海森图纸张，需要知道Q的最大值来确定横坐标的上限
fig = plt.figure(figsize=(10,7))
ax1 = fig.add_subplot(111)
for i in range(len(x)):
    plt.vlines(x[i], 0, 3000, 'deepskyblue', '--',linewidth=0.7)
for j in range(len(y_axis)):
    plt.hlines(y_axis[j], 0, max(y_axis), 'deepskyblue', '--',linewidth=0.7)
plt.xticks(x, x_axis, color='black', rotation=0)
plt.yticks(y_axis, y_ticks, color='black', rotation=0)

plt.ylim(0, 3000)
plt.xlim(0, round(max(x) + 0.1, 2))
plt.tick_params(labelsize=10)

# 绘制原始数据的散点图
qj = np.mean(Q)
qcv = np.std(Q) * np.sqrt(len(Q) / (len(Q) - 1)) / qj  # 无偏估计的cv值,标准差除均值
Q.sort(reverse=True)
# print(Q)
pq = [(i + 1) *100/ (len(Q) + 1) for i in range(len(Q))]  # Q的经验频率 P=m/(n+1)，通过期望公式，见书本P50
# print(pq)
pqx = xtrans(pq)
plt.scatter(pqx, Q)
# 绘制预测的概率曲线，需要知道cs,cv,qj（均值）
n = 2  # 是自定义值
cs = n * qcv
qj_rounded = round(qj, 2)
qcv_rounded = round(qcv, 2)
cs_rounded = round(cs, 2)

qpredict = [qj * (qcv * m + 1) for m in jlxs(pstandard, cs)]
plt.plot(x, qpredict, 'r', '-')
font2={'family':'Times New Roman','size':16,'color':'k'}
plt.title('Peak Flow P-III Frequency Curve',fontdict=font2)
plt.xlabel('Frequency (%)',fontdict=font2)
plt.ylabel('Flow (m³/s)',fontdict=font2)
plt.text(x=0.85, y=0.85, s=f"Ex={qj_rounded}\nCv={qcv_rounded}\nCs={cs_rounded}", size = 15,\
         family = "Times New Roman", color = "black", weight = "normal",\
         ha="center", va="center", transform=ax1.transAxes,\
         bbox = dict(facecolor = "w", alpha = 1))
plt.savefig('peak_flow_p3_frequency_curve.png', dpi=500)
#plt.show()

return_periods = [2, 5, 10, 20, 50]  # 可以根据需求设置不同的重现期
probabilities = [50,20,10,5,2]  # 计算对应的概率

# 根据概率计算洪峰流量
# 假设jlxs是用来计算流量的函数
cs = n * qcv  # 这个是从代码中的计算方式得出的参数
qpredict2 = [qj * (qcv * m + 1) for m in jlxs(probabilities, cs)]
for T, P, q in zip(return_periods, probabilities, qpredict2):
    print(f"重现期 {T} 年，对应的洪峰流量为: {q:.2f} m^3/s")

import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
from scipy.stats import genextreme

# 设定Excel文件所在的文件夹路径
file_directory = './data1/'

# 获取所有Excel文件的列表

excel_files = [f for f in os.listdir(file_directory) if f.endswith('.xlsx')]

# 提取文件名中的数字并排序
def extract_number(filename):
    # 提取文件名中的数字部分
    number = ''.join(filter(str.isdigit, filename))
    return int(number) if number else 0  # 如果没有数字部分，返回0

# 按照提取的数字部分进行排序
excel_files_sorted = sorted(excel_files, key=extract_number)
print(excel_files_sorted)

# 读取所有Excel文件并计算每场洪水的洪峰流量和降水总量
flood_peak_flows = []  # 存储洪峰流量
rain_totals = []  # 存储降水总量

area=484.467916046662

for file in excel_files_sorted:
    file_path = os.path.join(file_directory, file)
    print(file_path)
    df = pd.read_excel(file_path, engine='openpyxl')  # header=None 表示不把第一行作为列名
    
    # 假设第8列是降水量，第9列是径流量（按0-based index）
    precipitation = df.iloc[:, 6] * 1000  # 降水量（第7列，索引6）    m to mm
    runoff = df.iloc[:, 8]*1000/(3.6/area) # 径流量（第9列，索引8）   m to m3/s
    
    # 计算洪峰流量和降水总量
    peak_flow = runoff.max()  # 洪峰流量为最大径流量
    total_rain = precipitation.sum()  # 降水总量为降水量的总和
    
    flood_peak_flows.append(peak_flow)
    rain_totals.append(total_rain)

# 将结果保存为 DataFrame
flood_data = pd.DataFrame({
    'File': ['19710606','19720506','19730528','19770517','19780803','19790611','19800412','19810601','19820512','19830515','19840427',\
    '19860713','19880525','19890619','19920624','19930502','19940421','19990812','20000402','20020720','20050623','20060526','20070610',\
   '20080626','20120624','19740625','19870522','19970617','20100507','20130516'],
    'Peak Flow': flood_peak_flows,
    'Total Rain': rain_totals
})
print(flood_data)

flood_data.to_excel('output_flood2.xlsx', index=False, engine='openpyxl')