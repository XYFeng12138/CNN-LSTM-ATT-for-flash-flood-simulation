import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow import keras
from keras.models import Model
from keras.layers import Input, LSTM, Dense, Conv2D, MaxPooling2D, Flatten, Concatenate, Reshape
from sklearn.model_selection import train_test_split

from keras import layers, models
from keras.optimizers import Adam
import time 
from sklearn.preprocessing import StandardScaler

from keras.callbacks import ReduceLROnPlateau

plt.rcParams['font.family'] = 'Times New Roman'

final_model = models.load_model('flood_prediction_model32.h5')
# 加载测试数据
X_rain_test = np.load('rainfall_data_test.npy')
X_evap_test = np.load('evaporation_data_test.npy')
X_terrain_test = np.load('dem_data_test.npy')
y_test = np.load('target_data_test.npy')

# 预测
startime2 = time.time()
predictions = final_model.predict([X_rain_test, X_evap_test, X_terrain_test])
endtime2 = time.time()
testtime2 = endtime2 -  startime2
print(f"Test completed in {testtime2 :.2f} seconds.")
# 计算误差
mse = np.mean((predictions - y_test) ** 2)
mae = np.mean(np.abs(predictions - y_test))
#rmse = np.sqrt(mean_squared_error(y_test, predictions ))

print(f'Mean Squared Error (MSE): {mse}')
print(f'Mean Absolute Error (MAE): {mae}')
#print(f'Mean Absolute Error (rmse): {rmse}')

#画图
import os
import matplotlib.pyplot as plt
import numpy as np

# 获取测试数据的维度信息
num_floods, num_hours, N, M = y_test.shape

# 指定保存图像的文件夹
plt.rcParams['font.family'] = 'Times New Roman'
output_dir = "real_comparison_plots311"
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# 获取测试数据的维度信息

# 对每个小时生成一张图，共输出100张
for hour in range(num_hours):
    plt.figure(figsize=(12, 8))
    
    # 第一场洪水 - Ground Truth
    ax1 = plt.subplot(2, 2, 1)
    im1 = ax1.imshow(y_test[0, hour, :, :], cmap='viridis')
    ax1.set_title(f'Flood 1 Ground Truth\nHour {hour+1}')
    plt.colorbar(im1, ax=ax1, fraction=0.046, pad=0.04)
    
    # 第一场洪水 - Prediction
    ax2 = plt.subplot(2, 2, 2)
    im2 = ax2.imshow(predictions[0, hour, :, :], cmap='viridis')
    ax2.set_title(f'Flood 1 Prediction\nHour {hour+1}')
    plt.colorbar(im2, ax=ax2, fraction=0.046, pad=0.04)
    
    # 第二场洪水 - Ground Truth
    ax3 = plt.subplot(2, 2, 3)
    im3 = ax3.imshow(y_test[1, hour, :, :], cmap='viridis')
    ax3.set_title(f'Flood 2 Ground Truth\nHour {hour+1}')
    plt.colorbar(im3, ax=ax3, fraction=0.046, pad=0.04)
    
    # 第二场洪水 - Prediction
    ax4 = plt.subplot(2, 2, 4)
    im4 = ax4.imshow(predictions[1, hour, :, :], cmap='viridis')
    ax4.set_title(f'Flood 2 Prediction\nHour {hour+1}')
    plt.colorbar(im4, ax=ax4, fraction=0.046, pad=0.04)
    
    plt.tight_layout()
    
    # 保存图片，文件名中包含小时编号，例如 comparison_hour_000.png, comparison_hour_001.png, ...
    save_path = os.path.join(output_dir, f'comparison_hour_{hour:03d}.png')
    plt.savefig(save_path)
    plt.close()

print(f"总共生成 {num_hours} 张对比图，保存在文件夹 '{output_dir}' 中。")

plt.rcParams['font.family'] = 'Times New Roman'
output_dir = "comparison_plots311"
if not os.path.exists(output_dir):
    os.makedirs(output_dir)



# 对每个小时生成一张图，共输出100张
for hour in range(num_hours):
    fig, axs = plt.subplots(2, 2, figsize=(12, 8))
    
    # 第一场洪水 - Ground Truth
    ax1 = axs[0, 0]
    data1 = np.ma.masked_where(np.isnan(y_test[0, hour, :, :]) | (y_test[0, hour, :, :] == 0), y_test[0, hour, :, :] )
    data1[data1 > 3] = 4
    im1 = ax1.imshow(data1, cmap='viridis', vmin=0, vmax=4)
    ax1.set_title(f'Flood "20100507" Test Value\nT = {hour+1} h',fontsize = font1 )
    ax1.set_xticks([])
    ax1.set_yticks([])

    # 第一场洪水 - Prediction
    ax2 = axs[0, 1]
   # data2 = np.ma.masked_where(np.isnan(predictions[0, hour, :, :]) | (predictions[0, hour, :, :] == 0), predictions[0, hour, :, :])
    data2 = np.ma.masked_where(
    (np.isnan(predictions[0, hour, :, :])) | 
    (predictions[0, hour, :, :] == 0) | 
    (predictions[0, hour, :, :] < 0.1),  # 小于0的值也掩码为透明
    predictions[0, hour, :, :]  )
    data2[data2 > 3] = 4
    im2 = ax2.imshow(data2, cmap='viridis', vmin=0, vmax=4)
    ax2.set_title(f'Flood "20100507" Prediction\nT = {hour+1} h' , fontsize = font1 )
    ax2.set_xticks([])
    ax2.set_yticks([])

    # 第二场洪水 - Ground Truth
    ax3 = axs[1, 0]
    data3 = np.ma.masked_where(np.isnan(y_test[1, hour, :, :]) | (y_test[1, hour, :, :] == 0), y_test[1, hour, :, :] )
    data3[data3 > 3] = 4
    im3 = ax3.imshow(data3, cmap='viridis', vmin=0, vmax=4)
    ax3.set_title(f'Flood "20130516" Test Value\nT = {hour+1} h',fontsize = font1 )
    ax3.set_xticks([])
    ax3.set_yticks([])

    # 第二场洪水 - Prediction
    ax4 = axs[1, 1]
   # data4 = np.ma.masked_where(np.isnan(predictions[1, hour, :, :]) | (predictions[1, hour, :, :] == 0), predictions[1, hour, :, :])
    data4 = np.ma.masked_where(
    (np.isnan(predictions[1, hour, :, :])) | 
    (predictions[1, hour, :, :] == 0) | 
    (predictions[1, hour, :, :] < 0.1),  # 小于0的值也掩码为透明
    predictions[1, hour, :, :]  )
    data4[data4 > 3] = 4
    im4 = ax4.imshow(data4, cmap='viridis', vmin=0, vmax=4)
    ax4.set_title(f'Flood "20130516" Prediction\nT = {hour+1} h',fontsize = font1 ) 
    ax4.set_xticks([])
    ax4.set_yticks([])

    # 调整子图间距
    plt.subplots_adjust(wspace=0.2, hspace=0.1)

    # 添加统一的colorbar
    cbar = plt.colorbar(im1, ax=axs, fraction=0.030, pad=0.02)
    cbar.set_ticks([0, 1, 2, 3, 4])
    cbar.set_ticklabels(['0', '1', '2', '3', '>3'])
    cbar.set_label('Water Depth (m)', fontsize=17)
    cbar.ax.tick_params(labelsize=14) 
    # 保存图片，文件名中包含小时编号
    save_path = os.path.join(output_dir, f'comparison_hour_{hour:03d}.png')
    plt.savefig(save_path,dpi = 500)
    plt.close()
import matplotlib.pyplot as plt
import numpy as np
import os

import matplotlib.pyplot as plt
import numpy as np
import os
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

plt.rcParams['font.family'] = 'Times New Roman'
output_dir = "error_plots311"
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# 获取测试数据和预测数据的维度信息
#num_hours, M, N = y_test.shape  # 假设y_test是T x M x N，且T等于num_hours
#assert predictions.shape == y_test.shape, "预测结果和测试数据形状不匹配"

# 初始化 RMSE、MAE 和 R² 数组

y_test_clean = np.nan_to_num(y_test, nan=0.0)
predictions_clean = np.nan_to_num(predictions, nan=0.0)


y_test_clean[y_test_clean <= 0] = 0
predictions_clean[predictions_clean <= 0] = 0

# 初始化误差度量的列表
rmse_values = []
mae_values = []
r2_values = []
rmse_values2 = []
mae_values2 = []
r2_values2 = []
font2 = 16
font3 = 16
# 逐小时计算误差
for hour in range(num_hours):
    # 提取当前小时的测试数据和预测数据
    y_true1 = y_test_clean[0,hour, :, :]
    y_true1  = y_true1.flatten()
    y_true2 = y_test_clean[1,hour, :, :]
    y_true2  = y_true2.flatten()
     
    y_pred1 = predictions_clean[0,hour, :, :] 
    y_pred1 = y_pred1.flatten()
    y_pred2 = predictions_clean[1,hour, :, :] 
    y_pred2 = y_pred2.flatten()

        # 计算RMSE、MAE和R²
    rmse1 = np.sqrt(mean_squared_error(y_true1, y_pred1))
    mae1 = mean_absolute_error(y_true1, y_pred1)
    r21 = r2_score(y_true1, y_pred1) 
    r21 = max(r21,0)
    rmse2 = np.sqrt(mean_squared_error(y_true2, y_pred2))
    mae2 = mean_absolute_error(y_true2, y_pred2)
    r22 = r2_score(y_true2, y_pred2) 
    r22 = max(r22,0)
    # 将误差添加到列表中
    rmse_values.append(rmse1)
    mae_values.append(mae1)
    r2_values.append(r21)

    rmse_values2.append(rmse2)
    mae_values2.append(mae2)
    r2_values2.append(r22)
    
    # 打印每个小时的误差统计
    print(f"Hour {hour + 1} - RMSE: {rmse1:.4f}, MAE: {mae1:.4f}, R²: {r21:.4f}")
    print(f"Hour {hour + 1} - RMSE: {rmse2:.4f}, MAE: {mae2:.4f}, R²: {r22:.4f}")
# 绘制误差统计量的时间序列图
plt.figure(figsize=(12, 6))
#plt.figure(figsize=(12, 6))
# 第一张子图，绘制 y_test[0, :, :, :]
plt.subplot(1, 2, 1)  # (1行2列，第一张图)


plt.plot(range(1, num_hours + 1), rmse_values, label='RMSE', color='#87CEFA', marker='s', markersize= 3)   #change
plt.plot(range(1, num_hours + 1), mae_values, label='MAE', color='#F4A460', marker='s',markersize = 3)
plt.plot(range(1, num_hours + 1), r2_values, label='R²', color='#3CB371', marker='s',markersize = 3)   #change
plt.title('Flood "20100507"',fontsize = font2)
plt.xlabel('Time (h)',fontsize = font3)
plt.tick_params(axis='both', which='major', labelsize=14)  
#plt.ylabel('Error Value')
#plt.legend(fontsize = font3)
plt.grid(True)

plt.subplot(1, 2, 2)  # (1行2列，第二张图)

plt.plot(range(1, num_hours + 1), rmse_values2, label='RMSE', color='#87CEFA', marker='s', markersize= 3)
plt.plot(range(1, num_hours + 1), mae_values2, label='MAE', color='#F4A460', marker='s',markersize = 3)
plt.plot(range(1, num_hours + 1), r2_values2, label='R²', color='#3CB371', marker='s',markersize = 3)
plt.title('Flood "20130516"' , fontsize = font2 )
plt.xlabel('Time (h)',fontsize = font3)
plt.tick_params(axis='both', which='major', labelsize=14)  
#plt.ylabel('Error Value')
plt.legend(fontsize = font2)
plt.grid(True)
plt.tight_layout()

# 保存统计图
save_path = os.path.join(output_dir, 'error_metrics_over_time5.png')
plt.savefig(save_path,dpi = 500)
plt.close()

import pandas as pd

# 假设你已经有了这些数据
# rmse_values, mae_values, r2_values, rmse_values2, mae_values2, r2_values2 都是已经计算好的列表

# 创建一个字典，将数据放在一起
data = {
    'Hour': range(1, num_hours + 1),
    'RMSE1': rmse_values,
    'MAE1': mae_values,
    'R²1': r2_values,
    'RMSE2': rmse_values2,
    'MAE2': mae_values2,
    'R²2': r2_values2
}

# 将字典转换为 DataFrame
df = pd.DataFrame(data)

# 输出为 Excel 文件
output_file = os.path.join(output_dir, 'error_metrics_table2.xlsx')
df.to_excel(output_file, index=False, engine='openpyxl')

print(f"Table has been saved to {output_file}")



